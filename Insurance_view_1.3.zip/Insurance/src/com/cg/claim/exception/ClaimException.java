package com.cg.claim.exception;

public class ClaimException extends Exception{

	public ClaimException(String message) {
		super(message);
		// TODO Auto-generated constructor stub
	}
	
	

}
