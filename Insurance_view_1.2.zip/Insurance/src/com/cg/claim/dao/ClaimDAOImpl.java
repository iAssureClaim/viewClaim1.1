package com.cg.claim.dao;

import java.io.IOException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;

import com.cg.claim.bean.Claim;
import com.cg.claim.bean.Policy;
import com.cg.claim.exception.ClaimException;
import com.cg.claim.util.DBConnection;

public class ClaimDAOImpl implements IClaimDAO{

	@Override
	public Claim viewClaim(long claimNumber) throws IOException {
		// TODO Auto-generated method stub
		Connection connection = DBConnection.getConnection();
		long data = claimNumber;
		Claim claim = null;
		try {
			PreparedStatement ps = connection.prepareStatement(QueryMapper.viewClaimQuery);
			ps.setLong(1, data);
			claim = new Claim();
			ResultSet rs = ps.executeQuery();
			if(rs==null) {
				throw new ClaimException("entered claim id is wrong");
			}else {
				
			}
			
			while (rs.next()) {
			
			claim.setClaimNumber(rs.getLong(1));
			claim.setClaimType(rs.getString(2));
			claim.setPolicyNumber(rs.getLong(3));
				
			}
		
		} catch (Exception e) {
			e.printStackTrace();
		}
		return claim;
	}

	@Override
	public Policy viewPolicy(long policyNumber) throws IOException {
		Connection connection = DBConnection.getConnection();
		long data = policyNumber;
		Policy policy = null;
		try {
			PreparedStatement ps = connection.prepareStatement(QueryMapper.viewPolicyQuery);
			ps.setLong(1, data);
			policy = new Policy();
			ResultSet rs = ps.executeQuery();
			if(rs==null) {
				throw new ClaimException("entered policy id is wrong");
			}else {
				
			}
			
			while (rs.next()) {
			
			policy.setPolicyNumber(rs.getLong(1));
			policy.setPolicyPremium(rs.getDouble(2));
			policy.setAccountNumber(rs.getLong(3));
				
			}
		
		} catch (Exception e) {
			e.printStackTrace();
		}
		return policy;
	}

	@Override
	public List<Policy> viewAllPolicy(String userName) throws IOException {
		Connection connection = DBConnection.getConnection();
		String name2=userName;
		 //null;
		int count=0;
		List<Policy> policyList = new ArrayList<Policy>();
		try {
			PreparedStatement ps = connection.prepareStatement(QueryMapper.viewAllPolicy);
			ps.setString(1, name2);
			ps.executeUpdate();
			ResultSet rs = ps.executeQuery();
			if(rs==null) {
				throw new ClaimException("entered user name is wrong/////THERE IS NO POLICY ASSOCIATED WITH THAT USER");
			}
			else {
				while (rs.next()) {
					Policy policy = new Policy();
					policy.setPolicyNumber(rs.getLong(1));
					policy.setPolicyPremium(rs.getDouble(2));
					policy.setAccountNumber(rs.getLong(3));
					policyList.add(policy);
					
					}
				return policyList;
			}
			
		
			
		}
		catch(Exception e)
		{
			e.printStackTrace();
		}
		return policyList;
		
			
		
	}

}
