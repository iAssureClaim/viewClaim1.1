package com.cg.claim.dao;

public interface QueryMapper {
	
	String viewClaimQuery = "select claim_number, claim_type, policy_number from claim where claim_number=?";
	String viewPolicyQuery="select policy_number, policy_premium, account_number from policy where policy_number=?";
	String viewAllPolicy="SELECT * FROM POLICY WHERE ACCOUNT_NUMBER=(SELECT ACCOUNT_NUMBER FROM ACCOUNT WHERE USER_NAME=(SELECT USER_NAME FROM USER_ROLE WHERE USER_NAME=?))";
}
