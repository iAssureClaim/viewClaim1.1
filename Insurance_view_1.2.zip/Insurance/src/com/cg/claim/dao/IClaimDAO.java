package com.cg.claim.dao;

import java.io.IOException;
import java.util.List;

import com.cg.claim.bean.Claim;
import com.cg.claim.bean.Policy;

public interface IClaimDAO {
	
	public Claim viewClaim(long claimNumber) throws IOException;
	
	public Policy viewPolicy(long policyNumber) throws IOException;
	
	public List<Policy> viewAllPolicy(String userName) throws IOException;
	
}
