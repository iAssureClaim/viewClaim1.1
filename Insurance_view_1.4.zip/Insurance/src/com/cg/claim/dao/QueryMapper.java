package com.cg.claim.dao;

public interface QueryMapper {
	
	String ViewClaim_By_Id = "select claim_number, claim_type, policy_number from claim where claim_number=?";
	String viewPolicy_by_id="select policy_number, policy_premium, account_number from policy where policy_number=?";
	String viewAllPolicies="SELECT * FROM POLICY WHERE ACCOUNT_NUMBER=(SELECT ACCOUNT_NUMBER FROM ACCOUNT WHERE USER_NAME=(SELECT USER_NAME FROM USER_ROLE WHERE USER_NAME=?))";
	String viewAllClaims=" select claim_number, claim_type, policy_number from claim where policy_number IN (select policy_number from policy where account_number IN (select account_number from account where user_name IN (select user_name from user_role where user_name=?)))";
}
