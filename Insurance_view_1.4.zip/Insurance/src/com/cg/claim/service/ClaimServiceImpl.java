package com.cg.claim.service;

import java.io.IOException;
import java.sql.SQLException;
import java.util.List;

import com.cg.claim.bean.Claim;
import com.cg.claim.bean.Policy;
import com.cg.claim.dao.ClaimDAOImpl;
import com.cg.claim.dao.IClaimDAO;
import com.cg.claim.exception.ClaimException;

public class ClaimServiceImpl implements IClaimService{

	IClaimDAO claimDao = new ClaimDAOImpl();
	@Override
	public Claim viewClaim(long claimNumber) throws IOException, ClaimException, SQLException {
	long data = claimNumber;
	Claim claim =claimDao.viewClaim(data);
		return claim;
	}
	@Override
	public Policy viewPolicy(long policyNumber) throws IOException, ClaimException, SQLException {
		long data = policyNumber;
		Policy policy =claimDao.viewPolicy(data);
			return policy;
		
	}
	@Override
	public List<Policy> viewAllPolicies(String userName) throws IOException, SQLException, ClaimException {
		// TODO Auto-generated method stub
			List<Policy> policyList=null;
		policyList=claimDao.viewAllPolicy(userName);
		return policyList;
	}
	@Override
	public List<Claim> viewAllClaims(String userName) throws IOException, SQLException, ClaimException {
		// TODO Auto-generated method stub
		List<Claim> claimList = null;
		claimList = claimDao.viewAllClaims(userName);
		return claimList;
	}
	
	

}
