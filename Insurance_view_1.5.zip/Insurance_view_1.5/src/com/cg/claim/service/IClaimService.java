package com.cg.claim.service;

import java.io.IOException;
import java.sql.SQLException;
import java.util.List;

import com.cg.claim.bean.Claim;
import com.cg.claim.bean.Policy;
import com.cg.claim.exception.ClaimException;

public interface IClaimService {

	public Claim viewClaim(long claimNumber) throws IOException, ClaimException, SQLException;
	
	public Policy viewPolicy(long policyNumber) throws IOException, ClaimException, SQLException;
	public List<Policy> viewAllPolicies(String userName) throws IOException, SQLException, ClaimException;
	
	public List<Claim> viewAllClaims(String userName) throws IOException, SQLException, ClaimException;
	
}
