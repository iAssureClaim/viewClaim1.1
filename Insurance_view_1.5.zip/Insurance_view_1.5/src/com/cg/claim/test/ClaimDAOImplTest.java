package com.cg.claim.test;

import static org.junit.Assert.*;

import java.io.IOException;
import java.sql.SQLException;

import org.junit.BeforeClass;
import org.junit.Test;

import com.cg.claim.bean.Account;
import com.cg.claim.bean.Claim;
import com.cg.claim.bean.Policy;
import com.cg.claim.bean.PolicyDetails;
import com.cg.claim.bean.UserRole;
import com.cg.claim.dao.ClaimDAOImpl;
import com.cg.claim.exception.ClaimException;

public class ClaimDAOImplTest {
	static ClaimDAOImpl dao;
	static Claim claim;
	static Account account;
	static Policy policy;
	static PolicyDetails policyDetails;
	static UserRole userRole;

	@BeforeClass
	public static void initialize()
	{
		System.out.println("in before class");
		dao=new ClaimDAOImpl();
		claim=new Claim();
		account = new Account();
		policy=new Policy();
		policyDetails=new PolicyDetails();
		userRole=new UserRole();
	}

	@Test
	public void testViewClaim() throws IOException, ClaimException, SQLException {
		
		assertNotNull(dao.viewClaim(1001));
	}
	@Test
	public void testViewPolicy() throws IOException, ClaimException, SQLException {
		
		assertNotNull(dao.viewPolicy(1000101));
	}
	@Test
	public void testViewAllClaim() throws IOException, ClaimException, SQLException {
		
		assertNotNull(dao.viewAllClaims("USER001"));
	}
	@Test
	public void testViewAllPolicy() throws IOException, ClaimException, SQLException {
		
		assertNotNull(dao.viewAllPolicy("USER001"));
	}

}
