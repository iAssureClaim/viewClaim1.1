package com.cg.claim.client;

import java.io.IOException;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.Scanner;

import org.apache.log4j.Logger;
import org.apache.log4j.PropertyConfigurator;

import com.cg.claim.bean.Claim;
import com.cg.claim.bean.Policy;
import com.cg.claim.dao.IClaimDAO;
import com.cg.claim.exception.ClaimException;
import com.cg.claim.service.ClaimServiceImpl;
import com.cg.claim.service.IClaimService;

public class Client {
	
	
	static Logger logger = Logger.getRootLogger();
	Claim claim = null;
	Policy policy=null;
	static IClaimService claimService = null;
	static Scanner scanner = new Scanner(System.in);
	
	
	public static void main(String[] args) throws IOException, ClaimException {
		
		PropertyConfigurator.configure("resources/Log4j.properties");
		
		int option = 0;
		
		while (true) {
			
			System.out.println("1.View Claim using Claim Number");
			System.out.println("2.View all Claims Of an user");
			System.out.println("3.View policy by suing policy Number");
			System.out.println("4.View all Policies");
			System.out.println("select an Option");
			
			
			option=scanner.nextInt();
			
			
			switch (option) {
			
			case 1:
				try
				{
				claimService= new ClaimServiceImpl();
				System.out.println("enter your claim id:");
				long data=scanner.nextLong();
				System.out.println(claimService.viewClaim(data));
				logger.info("claim is generated");
				}
				
				catch (Exception e) {
                   System.out.println(e);
                   logger.error("Exception Occured", e);
                   }finally {
					claimService = null;
				}
				break;
			case 2:
				try {
					claimService = new ClaimServiceImpl();
					List<Claim> claimList = new ArrayList<Claim>();
					System.out.println("Enter your User Name");
					String name = scanner.next();
					claimList = claimService.viewAllClaims(name);
					if(claimList!=null) {
						Iterator<Claim> i = claimList.iterator();
						while (i.hasNext()) {
							System.out.println(i.next());
						}
						
					}else {
						System.out.println("There are No Claims");
					}
					logger.info("policy is generated");
				} catch (Exception e) {
					// TODO: handle exception
					logger.error("Exception ocuured", e);
					e.printStackTrace();
					
					
				}
				
				break;
			case 3:
				try
				{
				claimService= new ClaimServiceImpl();
				System.out.println("enter your policy id:");
				long data=scanner.nextLong();
				System.out.println(claimService.viewPolicy(data));
				logger.info("claim list  is generated");
				}
				catch (Exception e) {
					logger.error("exception occured", e);
                System.out.println(e);			
                }
				break;
				
			case 4:
				try {
					claimService= new ClaimServiceImpl();
					List<Policy> policyList = new ArrayList<Policy>();
					System.out.println("Enter your user name: ");
					String name=scanner.next();
					policyList=claimService.viewAllPolicies(name);
					if(policyList != null)
					{
						Iterator<Policy> i=policyList.iterator();
						while(i.hasNext())
						{
							System.out.println(i.next());
						}
					}
					else
					{
						System.out.println("no policies");
					}
					
					logger.info("policy list  is generated");
				}
				catch(Exception e)
				{
					logger.error("Exception Occured", e);
					e.printStackTrace();
				}
				break;
				
			default:
				break;
			
			}
			
			
		}

	
	
	
	}
}
